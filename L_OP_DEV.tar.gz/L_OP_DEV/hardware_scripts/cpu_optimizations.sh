#!/bin/bash

##################################################################
#IMPORTANT: SCRIPT DIRS SETUP (OPTIMIZATIONS)
source ./utility_scripts/script_directories.sh
source $SAVED_OPTIMIZATION_GOALS
source $SAVED_CPU_DATA
source $SAVED_RAM_DATA
source $SAVED_ROOT_STORAGE_DATA
source $SAVED_SWAP_STORAGE_DATA
source $SAVED_OS_DATA
source $SAVED_DE_DATA
source $SAVED_BOOTLOADER_DATA
##################################################################

BASIC_CPU_COOLING_PROFILES=(
    "cpu_cooling_basic"
    "cpu+gpu_cooling_basic"
	"cpu+gpu_cooling+zram_basic"
	"cpu_cooling+zram_basic"
)

cpu_multithreading_optimizations(){

	if [[ $CPU_MULTITHREADING_SETTING == "enabled" && $CPU_MULTITHREADING_ACTIVE == "false" ]]; then
		echo on | sudo tee /sys/devices/system/cpu/smt/control
	elif [[ $CPU_MULTITHREADING_SETTING == "disabled" && $CPU_MULTITHREADING_ACTIVE == "true" ]]; then
		echo off | sudo tee /sys/devices/system/cpu/smt/control
	fi
 
	#CHECKS IF MULTITHREADING SETTING IS APPLIED CORRECTLY:
	CPU_MULTITHREADING_APPLIED=$(cat /sys/devices/system/cpu/smt/control)

	if [[ $CPU_MULTITHREADING_SETTING == "enabled" && $CPU_MULTITHREADING_ACTIVE == "false" ]]; then
		if [[ $CPU_MULTITHREADING_APPLIED == "on" || $CPU_MULTITHREADING_APPLIED == "1" ]]; then
			CPU_MULTITHREADING_ACTIVE="true"
		fi
	elif [[ $CPU_MULTITHREADING_SETTING == "disabled" && $CPU_MULTITHREADING_ACTIVE == "true" ]]; then
		if [[ $CPU_MULTITHREADING_APPLIED == "off" || $CPU_MULTITHREADING_APPLIED == "0" ]]; then
			CPU_MULTITHREADING_ACTIVE="false"
		fi
	fi

}

intel_cpu_auto_power_tuner(){

	if [[ $CPU_MULTITHREADING_ACTIVE == "false" ]]; then
		if (( $CURRENT_CPU_TDP_INTEL_HUMAN_READABLE > 40 )); then
			TDP_DECREASE_VALUE=$(($CURRENT_CPU_TDP_INTEL/4)) #Limits power usage
			NEW_TDP=$(($CURRENT_CPU_TDP_INTEL-$TDP_DECREASE_VALUE))
			TDP_TO_APPLY=$NEW_TDP
		elif (( $CURRENT_CPU_TDP_INTEL_HUMAN_READABLE > 20 )); then
			TDP_DECREASE_VALUE=$(($CURRENT_CPU_TDP_INTEL/5)) #Limits power usage
			NEW_TDP=$(($CURRENT_CPU_TDP_INTEL-$TDP_DECREASE_VALUE))
			TDP_TO_APPLY=$NEW_TDP
		elif (( $CURRENT_CPU_TDP_INTEL_HUMAN_READABLE < 10 )); then
			TDP_NEW_VALUE=$(($CURRENT_CPU_TDP_INTEL_HUMAN_READABLE*2)) #Low-powered CPUs need to boost beyond TDP to keep up usable performance, without intervention from the script, it could boost even higher on it's own.
			NEW_TDP=$(($TDP_NEW_VALUE*1000000))
			TDP_TO_APPLY=$NEW_TDP
		else
			TDP_NEW_VALUE=$(($CURRENT_CPU_TDP_INTEL_HUMAN_READABLE)) #Limits power usage
			NEW_TDP=$(($TDP_NEW_VALUE*1000000))
			TDP_TO_APPLY=$NEW_TDP
		fi
	else
		if (( $CURRENT_CPU_TDP_INTEL_HUMAN_READABLE > 40 )); then
			TDP_DECREASE_VALUE=$(($CURRENT_CPU_TDP_INTEL/3)) #Limits power usage
			NEW_TDP=$(($CURRENT_CPU_TDP_INTEL-$TDP_DECREASE_VALUE))
			TDP_TO_APPLY=$NEW_TDP
		elif (( $CURRENT_CPU_TDP_INTEL_HUMAN_READABLE > 20 )); then
			TDP_DECREASE_VALUE=$(($CURRENT_CPU_TDP_INTEL/4)) #Limits power usage
			NEW_TDP=$(($CURRENT_CPU_TDP_INTEL-$TDP_DECREASE_VALUE))
			TDP_TO_APPLY=$NEW_TDP
		elif (( $CURRENT_CPU_TDP_INTEL_HUMAN_READABLE < 10 )); then
			TDP_NEW_VALUE=$(($CURRENT_CPU_TDP_INTEL_HUMAN_READABLE*2)) #Low-powered CPUs need to boost beyond TDP to keep up usable performance, without intervention from the script, it could boost even higher on it's own.
			NEW_TDP=$(($TDP_NEW_VALUE*1000000))
			TDP_TO_APPLY=$NEW_TDP
		else
			TDP_NEW_VALUE=$(($CURRENT_CPU_TDP_INTEL_HUMAN_READABLE)) #Limits power usage
			NEW_TDP=$(($TDP_NEW_VALUE*1000000))
			TDP_TO_APPLY=$NEW_TDP
		fi
	fi

	#INTEL ONLY:
	#Enables TDP control (NOT CONFIRMED TO WORK OR DO ANYHING YET)
	# echo 1 |  tee /sys/class/powercap/intel-rapl/enabled (ONLY NEEDS intel-rapl:0 TO BE SET)
	for CPU_POWERCAP in /sys/class/powercap/intel-rapl*/enabled; do
		echo 1 | tee "$CPU_POWERCAP"
	done
	#Applies TDP to current CPU
	for CPU_LIMIT in /sys/class/powercap/intel-rapl*/constraint_*_power_limit_uw; do
        echo "$TDP_TO_APPLY" | tee "$CPU_LIMIT"
        APPLIED_TDP=$(<"$CPU_LIMIT")
        if (( $TDP_TO_APPLY >= $APPLIED_TDP )); then
            export TDP_APPLIED_CORRECTLY="true"
        else
            export TDP_APPLIED_CORRECTLY="false"
        fi
    done

}

cpu_scheduler_optimizations(){
	#General Optimizations
	echo 0 |  tee /sys/kernel/debug/sched/tunable_scaling
	echo 0 |  tee /sys/kernel/debug/sched/verbose
	
	if [[ "$CPU_OPTIMIZATION_GOAL" == "latency" ]]; then
        #NOTE: LOWERING "base_slice_ns" FURTHER WILL RESULT IN SERIOUS STUTTERING IN GAMING WORKLOADS
		if [[ $CPU_CLASS == "verylow" ]]; then

			if [[ $OPTIMIZATION_PROFILE_USECASE == "gaming" ]]; then
                echo 40000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 400000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 1 | tee /proc/sys/kernel/sched_numa_migrate
				echo 1 | tee /sys/kernel/debug/sched/nr_migrate
			elif [[ $OPTIMIZATION_PROFILE_USECASE == "desktop" ]]; then
				echo 50000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 500000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 2 | tee /proc/sys/kernel/sched_numa_migrate
				echo 1 | tee /sys/kernel/debug/sched/nr_migrate
    		else
				echo 60000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 600000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 4 | tee /proc/sys/kernel/sched_numa_migrate
				echo 1 | tee /sys/kernel/debug/sched/nr_migrate
    		fi

		elif [[ $CPU_CLASS == "low" ]]; then

			if [[ $OPTIMIZATION_PROFILE_USECASE == "gaming" ]]; then
                echo 30000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 300000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 2 | tee /proc/sys/kernel/sched_numa_migrate
				echo 1 | tee /sys/kernel/debug/sched/nr_migrate
			elif [[ $OPTIMIZATION_PROFILE_USECASE == "desktop" ]]; then
				echo 40000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 400000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 4 | tee /proc/sys/kernel/sched_numa_migrate
				echo 2 | tee /sys/kernel/debug/sched/nr_migrate
			else
				echo 50000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 500000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 8 | tee /proc/sys/kernel/sched_numa_migrate
				echo 3 | tee /sys/kernel/debug/sched/nr_migrate
			fi

		elif [[ $CPU_CLASS == "mid" ]]; then

			if [[ $OPTIMIZATION_PROFILE_USECASE == "gaming" ]]; then
                echo 20000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 200000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 4 | tee /proc/sys/kernel/sched_numa_migrate
				echo 2 | tee /sys/kernel/debug/sched/nr_migrate
			elif [[ $OPTIMIZATION_PROFILE_USECASE == "desktop" ]]; then
				echo 30000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 300000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 8 | tee /proc/sys/kernel/sched_numa_migrate
				echo 3 | tee /sys/kernel/debug/sched/nr_migrate
			else
				echo 40000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 400000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 16 | tee /proc/sys/kernel/sched_numa_migrate
				echo 4 | tee /sys/kernel/debug/sched/nr_migrate
			fi

		elif [[ $CPU_CLASS == "high" ]]; then

			if [[ $OPTIMIZATION_PROFILE_USECASE == "gaming" ]]; then
				echo 10000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 1000000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 8 | tee /proc/sys/kernel/sched_numa_migrate
				echo 3 | tee /sys/kernel/debug/sched/nr_migrate
			elif [[ $OPTIMIZATION_PROFILE_USECASE == "desktop" ]]; then
				echo 20000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 2000000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 16 | tee /proc/sys/kernel/sched_numa_migrate
				echo 4 | tee /sys/kernel/debug/sched/nr_migrate
			else
				echo 30000 | tee /sys/kernel/debug/sched/base_slice_ns
				echo 3000000 | tee /sys/kernel/debug/sched/migration_cost_ns
				echo 32 | tee /proc/sys/kernel/sched_numa_migrate
				echo 5 | tee /sys/kernel/debug/sched/nr_migrate
			fi

		fi
	elif [[ "$CPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
	
		if [[ $CPU_CLASS == "verylow" ]]; then
			echo 200000 |  tee /sys/kernel/debug/sched/base_slice_ns
			echo 20000000 |  tee /sys/kernel/debug/sched/migration_cost_ns
            echo 16 |  tee /proc/sys/kernel/sched_numa_migrate
            echo 10 |  tee /sys/kernel/debug/sched/nr_migrate
		elif [[ $CPU_CLASS == "low" ]]; then
			echo 400000 |  tee /sys/kernel/debug/sched/base_slice_ns
			echo 40000000 |  tee /sys/kernel/debug/sched/migration_cost_ns
            echo 32 |  tee /proc/sys/kernel/sched_numa_migrate
            echo 15 |  tee /sys/kernel/debug/sched/nr_migrate
		elif [[ $CPU_CLASS == "mid" ]]; then
			echo 800000 |  tee /sys/kernel/debug/sched/base_slice_ns
			echo 80000000 |  tee /sys/kernel/debug/sched/migration_cost_ns
            echo 64 |  tee /proc/sys/kernel/sched_numa_migrate
            echo 20 |  tee /sys/kernel/debug/sched/nr_migrate
		elif [[ $CPU_CLASS == "high" ]]; then
			echo 1600000 |  tee /sys/kernel/debug/sched/base_slice_ns
			echo 160000000 |  tee /sys/kernel/debug/sched/migration_cost_ns
            echo 128 |  tee /proc/sys/kernel/sched_numa_migrate
            echo 25 |  tee /sys/kernel/debug/sched/nr_migrate
		fi

	fi
}

cpu_performance_optimizations(){

	if [[ $CPU_CLASS == "verylow" ]]; then
		echo auto | tee "$CPU_PATH/power/control"
	else
		echo on | tee "$CPU_PATH/power/control"
	fi
	
	if [[ $OPTIMIZATION_PROFILE_USECASE == "server" ]]; then
        echo "enabled" | tee "$CPU_DIR/power/async"
    else
        echo "disabled" | tee "$CPU_DIR/power/async"
	fi

	CPU_GOVERNOR="performance"
	CPU_ENERGY_PERFORMANCE_PREFERENCE="performance"

	for ((i=0; i<CPU_THREADS; i++)); do

	    CPU_DIR="$CPU_PATH/cpu$i"

	    if [[ $CPU_CLASS == "verylow" ]]; then
		    echo auto | tee "$CPU_DIR/power/control"
	    else
		    echo on | tee "$CPU_DIR/power/control"
	    fi
	    
	    if [[ $OPTIMIZATION_PROFILE_USECASE == "server" ]]; then
	    	echo "enabled" | tee "$CPU_DIR/power/async"
	    else
	    	echo "disabled" | tee "$CPU_DIR/power/async" #Specially for gaming, it has to be disabled, else it gives rendering issues, specially with frame generation
	    fi

	    echo "$CPU_GOVERNOR" | tee "$CPU_DIR/cpufreq/scaling_governor"
	    echo "$CPU_ENERGY_PERFORMANCE_PREFERENCE" | tee "$CPU_DIR/cpufreq/energy_performance_preference"
	
	done
	
}

cpu_frequency_optimizations(){
    #Slightly reduces max freq to lower temperatures, to compensate, min freq in increased

	#BASE VALUES
	CPU_MIN_PERF_PERCENTAGE=1
	CPU_MAX_PERF_PERCENTAGE=100
	#USED ONLY IF ENABLED ADDITIONAL/EXTREME CPU COOLING SETTINGS
	CPU_MIN_PERF_PERCENTAGE_REDUCTION=0
	CPU_MAX_PERF_PERCENTAGE_REDUCTION=0

	if [[ $CPU_MULTITHREADING_ACTIVE == "false" ]]; then

		if [[ $CPU_CLASS == "verylow" ]]; then
			CPU_MIN_PERF_PERCENTAGE=15
			CPU_MAX_PERF_PERCENTAGE=85
		elif [[ $CPU_CLASS == "low" ]]; then
			CPU_MIN_PERF_PERCENTAGE=20
			CPU_MAX_PERF_PERCENTAGE=90
		elif [[ $CPU_CLASS == "mid" ]]; then
			CPU_MIN_PERF_PERCENTAGE=25
			CPU_MAX_PERF_PERCENTAGE=95
		elif [[ $CPU_CLASS == "high" ]]; then
			CPU_MIN_PERF_PERCENTAGE=30
			CPU_MAX_PERF_PERCENTAGE=98
		fi

		if [[ $EXTREME_CPU_COOLING == "enabled" || $ADDITIONAL_CPU_COOLING == "enabled" ]]; then
			if [[ $EXTREME_CPU_COOLING == "enabled" ]]; then
				CPU_MIN_PERF_PERCENTAGE_REDUCTION=10
				CPU_MAX_PERF_PERCENTAGE_REDUCTION=20
			elif [[ $ADDITIONAL_CPU_COOLING == "enabled" ]]; then
				CPU_MIN_PERF_PERCENTAGE_REDUCTION=5
				CPU_MAX_PERF_PERCENTAGE_REDUCTION=10
			fi
			CPU_MIN_PERF_PERCENTAGE=$(( CPU_MIN_PERF_PERCENTAGE - CPU_MIN_PERF_PERCENTAGE_REDUCTION ))
			CPU_MAX_PERF_PERCENTAGE=$(( CPU_MAX_PERF_PERCENTAGE - CPU_MAX_PERF_PERCENTAGE_REDUCTION ))
		fi

	else

		if [[ $CPU_CLASS == "verylow" ]]; then
			CPU_MIN_PERF_PERCENTAGE=10
			CPU_MAX_PERF_PERCENTAGE=80
		elif [[ $CPU_CLASS == "low" ]]; then
			CPU_MIN_PERF_PERCENTAGE=15
			CPU_MAX_PERF_PERCENTAGE=85
		elif [[ $CPU_CLASS == "mid" ]]; then
			CPU_MIN_PERF_PERCENTAGE=20
			CPU_MAX_PERF_PERCENTAGE=90
		elif [[ $CPU_CLASS == "high" ]]; then
			CPU_MIN_PERF_PERCENTAGE=25
			CPU_MAX_PERF_PERCENTAGE=95
		fi

		if [[ $EXTREME_CPU_COOLING == "enabled" || $ADDITIONAL_CPU_COOLING == "enabled" ]]; then
			if [[ $EXTREME_CPU_COOLING == "enabled" ]]; then
				CPU_MIN_PERF_PERCENTAGE_REDUCTION=10
				CPU_MAX_PERF_PERCENTAGE_REDUCTION=30
			elif [[ $ADDITIONAL_CPU_COOLING == "enabled" ]]; then
				CPU_MIN_PERF_PERCENTAGE_REDUCTION=5
				CPU_MAX_PERF_PERCENTAGE_REDUCTION=15
			fi
			CPU_MIN_PERF_PERCENTAGE=$(( CPU_MIN_PERF_PERCENTAGE - CPU_MIN_PERF_PERCENTAGE_REDUCTION ))
			CPU_MAX_PERF_PERCENTAGE=$(( CPU_MAX_PERF_PERCENTAGE - CPU_MAX_PERF_PERCENTAGE_REDUCTION ))
		fi

	fi

	CPU_MIN_PERF=$(( CPU_MAX_FREQ * CPU_MIN_PERF_PERCENTAGE / 100 ))
	CPU_MAX_PERF=$(( CPU_MAX_FREQ * CPU_MAX_PERF_PERCENTAGE / 100 ))

    for ((i=0; i<CPU_THREADS; i++)); do
		CPU_DIR="$CPU_PATH/cpu$i"
    	echo $CPU_MAX_PERF | tee $CPU_DIR/cpufreq/scaling_max_freq
    	echo $CPU_MIN_PERF | tee $CPU_DIR/cpufreq/scaling_min_freq
    done

}

if [[ "$@" == "cpu_scheduler_optimizations" ]]; then
    cpu_scheduler_optimizations
elif [[ "$@" == "cpu_performance_optimizations" ]]; then
    cpu_performance_optimizations
elif [[ "$@" == "intel_cpu_auto_power_tuner" ]]; then
    intel_cpu_auto_power_tuner
elif [[ "$@" == "cpu_frequency_optimizations" ]]; then
    cpu_frequency_optimizations
else
	cpu_multithreading_optimizations
	if [[ " ${BASIC_CPU_COOLING_PROFILES[*]} " == *" $OPTIMIZATION_PROFILE "* ]]; then
		cpu_frequency_optimizations
	else
		cpu_scheduler_optimizations
		if [[ "$CPU_COOLING_OPTIMIZATION" == "enabled" ]]; then
			cpu_frequency_optimizations
		fi
		cpu_performance_optimizations
	fi
fi
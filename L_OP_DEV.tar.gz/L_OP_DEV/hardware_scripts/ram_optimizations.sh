#!/bin/bash

##################################################################
#IMPORTANT: SCRIPT DIRS SETUP (OPTIMIZATIONS)
source ./utility_scripts/script_directories.sh
source $SAVED_OPTIMIZATION_GOALS
source $SAVED_CPU_DATA
source $SAVED_RAM_DATA
source $SAVED_ROOT_STORAGE_DATA
source $SAVED_SWAP_STORAGE_DATA
source $SAVED_OS_DATA
source $SAVED_DE_DATA
source $SAVED_BOOTLOADER_DATA
##################################################################

ram_swappiness(){
	if [[ "$RAM_OPTIMIZATION_GOAL" == "latency" ]]; then
		if [[ $RAM_CLASS == "verylow" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 200 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 225 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 200 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
            	echo 20 |  tee /proc/sys/vm/swappiness
				echo 250 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "low" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 150 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 175 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 150 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
            	echo 15 |  tee /proc/sys/vm/swappiness
				echo 200 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "mid" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 100 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 125 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 100 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
            	echo 10 |  tee /proc/sys/vm/swappiness
				echo 150 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "high" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 50 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 75 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 50 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
            	echo 5 |  tee /proc/sys/vm/swappiness
				echo 100 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "veryhigh" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 10 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 25 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 10 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
            	echo 1 |  tee /proc/sys/vm/swappiness
				echo 50 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		fi
	
	elif [[ "$RAM_OPTIMIZATION_GOAL" == "throughput" ]]; then
		if [[ $RAM_CLASS == "verylow" ]]; then
			echo 200 |  tee /proc/sys/vm/swappiness
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 375 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 350 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
				echo 180 |  tee /proc/sys/vm/swappiness
				echo 400 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "low" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 200 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 325 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 300 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
				echo 160 |  tee /proc/sys/vm/swappiness
				echo 350 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "mid" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 200 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 275 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 250 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
				echo 140 |  tee /proc/sys/vm/swappiness
				echo 300 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "high" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 200 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 225 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 200 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
				echo 120 |  tee /proc/sys/vm/swappiness
				echo 250 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		elif [[ $RAM_CLASS == "veryhigh" ]]; then
			if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
				echo 200 |  tee /proc/sys/vm/swappiness
				if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
					echo 175 |  tee /proc/sys/vm/vfs_cache_pressure
				else
					echo 150 |  tee /proc/sys/vm/vfs_cache_pressure
				fi
			else
				echo 100 |  tee /proc/sys/vm/swappiness
				echo 200 |  tee /proc/sys/vm/vfs_cache_pressure
			fi
		fi
	fi
	
}

ram_deduplication(){

	#Enable RAM deduplication:
	echo 1 |  tee /sys/kernel/mm/ksm/run
	
	#LATENCY FOCUSED RAM DEDUPLICATION:
	if [[ "$CPU_OPTIMIZATION_GOAL" == "latency" ]]; then
		if [[ $CPU_CLASS == "verylow" ]]; then
			echo 250 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 40 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 256000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		elif [[ $CPU_CLASS == "low" ]]; then
			echo 500 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 30 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 512000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		elif [[ $CPU_CLASS == "mid" ]]; then
			echo 750 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 20 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 768000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		elif [[ $CPU_CLASS == "high" ]]; then
			echo 1000 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 10 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 1024000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		else
			echo "ERROR WITH MEMORY DEDUPLICATION: ERROR DETECTING CPU_CLASS, SKIPPING"
		fi
		
	#THROUGHPUT FOCUSED RAM DEDUPLICATION:
	elif [[ "$CPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
		if [[ $CPU_CLASS == "verylow" ]]; then
			echo 1250 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 200 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 1280000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		elif [[ $CPU_CLASS == "low" ]]; then
			echo 1500 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 200 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 1536000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		elif [[ $CPU_CLASS == "mid" ]]; then
			echo 1750 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 200 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 1792000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		elif [[ $CPU_CLASS == "high" ]]; then
			echo 2000 |  tee /sys/kernel/mm/ksm/pages_to_scan
			echo 200 |  tee /sys/kernel/mm/ksm/sleep_millisecs
			echo 2048000 |  tee /sys/kernel/mm/ksm/max_page_sharing
		else
			echo "ERROR WITH MEMORY DEDUPLICATION: ERROR DETECTING CPU_CLASS, SKIPPING"
		fi
	fi	
}

ram_vm_optimizations(){
    if [[ $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
		if [[ "$RAM_OPTIMIZATION_GOAL" == "latency" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 10 |  tee /proc/sys/vm/stat_interval
			else
				echo 20 |  tee /proc/sys/vm/stat_interval
			fi
		elif [[ "$RAM_OPTIMIZATION_GOAL" == "throughput" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 20 |  tee /proc/sys/vm/stat_interval
			else
				echo 40 |  tee /proc/sys/vm/stat_interval
			fi
		fi
	    if [[ $RAM_CLASS == "verylow" ]]; then
		    echo 70 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((32 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes #Start flushing at 32 MB
		    echo $((128 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes #Hard cap at 128 MB
			if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 800 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 400 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 1600 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 800 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "low" ]]; then
		    echo 80 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((64 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
		    if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 1000 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 500 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 2000 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 1000 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "mid" ]]; then
		    echo 90 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((128 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((512 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
		    if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 1200 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 600 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 2400 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 1200 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "high" ]]; then
		    echo 95 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((1024 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
		    if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 1400 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 700 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 2800 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 1400 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "veryhigh" ]]; then
		    echo 100 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((512 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((2048 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
		    if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 1600 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 800 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 3200 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 1600 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    fi

    elif [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" ]]; then
		if [[ "$RAM_OPTIMIZATION_GOAL" == "latency" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 20 |  tee /proc/sys/vm/stat_interval
			else
				echo 40 |  tee /proc/sys/vm/stat_interval
			fi
		elif [[ "$RAM_OPTIMIZATION_GOAL" == "throughput" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 40 |  tee /proc/sys/vm/stat_interval
			else
				echo 80 |  tee /proc/sys/vm/stat_interval
			fi
		fi
	    if [[ $RAM_CLASS == "verylow" ]]; then
		    echo 70 |  tee /proc/sys/vm/overcommit_ratio
            #Changing these value seems to help lower the USB device's temps, very important for portable installs, specially SD cards which can get VERY HOT under I/O pressure. NOTE: Using either too low or too high values can create extremely high temperatures for target device, use carefully.
		    echo $((16 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((64 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 400 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 200 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 800 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 400 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
		    echo 5 | tee /proc/sys/vm/laptop_mode
	    elif [[ $RAM_CLASS == "low" ]]; then
		    echo 80 |  tee /proc/sys/vm/overcommit_ratio
		    #Lowering these value seems to help lower the USB device's temps, very important for portable installs, specially SD cards which can get VERY HOT under I/O pressure
		    echo $((32 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((128 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 600 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 300 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 1200 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 600 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
    	    echo 5 | tee /proc/sys/vm/laptop_mode
	    elif [[ $RAM_CLASS == "mid" ]]; then
		    echo 90 |  tee /proc/sys/vm/overcommit_ratio
		    #Lowering these value seems to help lower the USB device's temps, very important for portable installs, specially SD cards which can get VERY HOT under I/O pressure
		    echo $((64 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 800 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 400 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 1600 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 800 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
    	    echo 5 | tee /proc/sys/vm/laptop_mode
	    elif [[ $RAM_CLASS == "high" ]]; then
		    echo 95 |  tee /proc/sys/vm/overcommit_ratio
            #Lowering these value seems to help lower the USB device's temps, very important for portable installs, specially SD cards which can get VERY HOT under I/O pressure
		    echo $((128 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((512 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
		    echo 500 | tee /proc/sys/vm/dirty_expire_centisecs
		    echo 250 | tee /proc/sys/vm/dirty_writeback_centisecs
			if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 1000 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 500 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 2000 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 1000 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
		    echo 5 | tee /proc/sys/vm/laptop_mode
	    elif [[ $RAM_CLASS == "veryhigh" ]]; then
		    echo 100 |  tee /proc/sys/vm/overcommit_ratio
    	    #Lowering these value seems to help lower the USB device's temps, very important for portable installs, specially SD cards which can get VERY HOT under I/O pressure
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((1024 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 1200 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 600 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$USB_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 2400 | tee /proc/sys/vm/dirty_expire_centisecs
				echo 1200 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
    	    echo 5 | tee /proc/sys/vm/laptop_mode
	    fi

    elif [[ $STORAGE_ROOT_DEVICE_TYPE == "ssd" ]]; then
		if [[ "$RAM_OPTIMIZATION_GOAL" == "latency" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 5 |  tee /proc/sys/vm/stat_interval
			else
				echo 10 |  tee /proc/sys/vm/stat_interval
			fi
		elif [[ "$RAM_OPTIMIZATION_GOAL" == "throughput" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 10 |  tee /proc/sys/vm/stat_interval
			else
				echo 20 |  tee /proc/sys/vm/stat_interval
			fi
		fi
	    if [[ $RAM_CLASS == "verylow" ]]; then
		    echo 70 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((32 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((128 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 200 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 100 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 400 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 200 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "low" ]]; then
		    echo 80 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((64 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
		    echo 131072 |  tee /proc/sys/vm/min_free_kbytes
			if [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 400 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 200 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 800 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 400 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "mid" ]]; then
		    echo 90 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((128 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((512 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 600 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 300 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 1200 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 600 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "high" ]]; then
		    echo 95 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((1024 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 800 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 400 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 1600 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 800 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "veryhigh" ]]; then
		    echo 100 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((512 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((2048 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 1000 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 500 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$SSD_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 2000 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 1000 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    fi
    elif [[ $STORAGE_ROOT_DEVICE_TYPE == "nvme" ]]; then
		if [[ "$RAM_OPTIMIZATION_GOAL" == "latency" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 2 |  tee /proc/sys/vm/stat_interval
			else
				echo 4 |  tee /proc/sys/vm/stat_interval
			fi
		elif [[ "$RAM_OPTIMIZATION_GOAL" == "throughput" ]]; then
			if [[ $CPU_CLASS == "high" ]]; then
				echo 5 |  tee /proc/sys/vm/stat_interval
			else
				echo 10 |  tee /proc/sys/vm/stat_interval
			fi
		fi
	    if [[ $RAM_CLASS == "verylow" ]]; then
		    echo 70 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((64 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 100 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 50 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 200 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 100 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "low" ]]; then
		    echo 80 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((128 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((512 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 200 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 100 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 400 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 200 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "mid" ]]; then
		    echo 90 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((256 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((1024 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 400 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 200 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 800 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 400 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "high" ]]; then
		    echo 95 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((512 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((2048 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 600 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 300 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 1200 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 600 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    elif [[ $RAM_CLASS == "veryhigh" ]]; then
		    echo 100 |  tee /proc/sys/vm/overcommit_ratio
		    echo $((1024 * 1024 * 1024)) | tee /proc/sys/vm/dirty_background_bytes
		    echo $((4096 * 1024 * 1024)) | tee /proc/sys/vm/dirty_bytes
			if [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "latency" ]]; then
				echo 800 | tee /proc/sys/vm/dirty_expire_centisecs
		    	echo 400 | tee /proc/sys/vm/dirty_writeback_centisecs
			elif [[ "$NVME_STORAGE_OPTIMIZATION_GOAL" == "throughput" ]]; then
				echo 1600 | tee /proc/sys/vm/dirty_expire_centisecs #Expire after 2 seconds
				echo 800 | tee /proc/sys/vm/dirty_writeback_centisecs
			fi
	    fi
    fi

	#NOTE: PAGE-CLUSTER VALUE INCREASES LOGARITHMICLY
    if [[ "$CPU_OPTIMIZATION_GOAL" == "latency" ]]; then
	    if [[ $CPU_CLASS == "verylow" ]]; then
	        echo 5 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 2 |  tee /proc/sys/vm/page_lock_unfairness
			echo 4 |  tee /proc/sys/vm/page-cluster
	    elif [[ $CPU_CLASS == "low" ]]; then
	        echo 10 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 3 |  tee /proc/sys/vm/page_lock_unfairness
			echo 5 |  tee /proc/sys/vm/page-cluster
	    elif [[ $CPU_CLASS == "mid" ]]; then
	        echo 15 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 4 |  tee /proc/sys/vm/page_lock_unfairness
			echo 6 |  tee /proc/sys/vm/page-cluster
	    elif [[ $CPU_CLASS == "high" ]]; then
	        echo 20 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 5 |  tee /proc/sys/vm/page_lock_unfairness
			echo 7 |  tee /proc/sys/vm/page-cluster
	    fi
    elif [[ "$CPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
	    if [[ $CPU_CLASS == "verylow" ]]; then
	        echo 10 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 5 |  tee /proc/sys/vm/page_lock_unfairness
			echo 9 |  tee /proc/sys/vm/page-cluster
	    elif [[ $CPU_CLASS == "low" ]]; then
	        echo 20 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 10 |  tee /proc/sys/vm/page_lock_unfairness
			echo 10 |  tee /proc/sys/vm/page-cluster
	    elif [[ $CPU_CLASS == "mid" ]]; then
	        echo 30 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 15 |  tee /proc/sys/vm/page_lock_unfairness
			echo 11 |  tee /proc/sys/vm/page-cluster
	    elif [[ $CPU_CLASS == "high" ]]; then
	        echo 40 |  tee /proc/sys/vm/compaction_proactiveness
	        echo 20 |  tee /proc/sys/vm/page_lock_unfairness
			echo 12 |  tee /proc/sys/vm/page-cluster
	    fi
    fi

	if [[ "$RAM_OPTIMIZATION_GOAL" == "latency" ]]; then
		if [[ $RAM_CLASS == "verylow" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 40 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 20 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 10 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 5 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "low" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 80 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 40 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 20 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 10 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "mid" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 120 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 60 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 30 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 15 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "high" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 160 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 80 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 40 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 20 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "veryhigh" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 100 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 50 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 50 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 25 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		fi
	elif [[ "$RAM_OPTIMIZATION_GOAL" == "throughput" ]]; then
		if [[ $RAM_CLASS == "verylow" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 200 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 100 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 100 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 50 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "low" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 400 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 200 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 200 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 100 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "mid" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 600 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 300 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 300 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 150 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "high" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 800 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 400 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 400 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 200 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		elif [[ $RAM_CLASS == "veryhigh" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "usb" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" ]]; then
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 1000 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 500 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			else
				if [[ $CPU_CLASS == "verylow" || $CPU_CLASS == "low" ]]; then
					echo 500 |  tee /proc/sys/vm/watermark_scale_factor
				else
					echo 250 |  tee /proc/sys/vm/watermark_scale_factor
				fi
				echo 0 |  tee /proc/sys/vm/watermark_boost_factor
			fi
		fi
	fi

	if [[ $RAM_CLASS == "verylow" ]]; then
		echo 262144 |  tee /proc/sys/vm/min_free_kbytes
		echo 65536 |  tee /proc/sys/vm/max_map_count
	elif [[ $RAM_CLASS == "low" ]]; then
		echo 524288 |  tee /proc/sys/vm/min_free_kbytes
		echo 131072 |  tee /proc/sys/vm/max_map_count
	elif [[ $RAM_CLASS == "mid" ]]; then
		echo 786432 |  tee /proc/sys/vm/min_free_kbytes
		echo 262144 |  tee /proc/sys/vm/max_map_count
	elif [[ $RAM_CLASS == "high" ]]; then
		echo 1048576 |  tee /proc/sys/vm/min_free_kbytes
		echo 327680 |  tee /proc/sys/vm/max_map_count
	elif [[ $RAM_CLASS == "veryhigh" ]]; then
		echo 1310720 |  tee /proc/sys/vm/min_free_kbytes
		echo 393216 |  tee /proc/sys/vm/max_map_count
	fi


	if [[ $OPTIMIZATION_PROFILE_USECASE == "server" ]]; then
		if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
			echo 4 |  tee /proc/sys/vm/zone_reclaim_mode
		else
			echo 1 |  tee /proc/sys/vm/zone_reclaim_mode
		fi
		
		if [[ $RAM_CLASS == "verylow" || $RAM_CLASS == "low" || $RAM_CLASS == "mid" ]]; then
			echo 0 |  tee /proc/sys/vm/overcommit_memory
		else
			if [[ "$CPU_CLASS" == "verylow" || "$CPU_CLASS" == "low" ]]; then
				echo 1 |  tee /proc/sys/vm/overcommit_memory
			else
				echo 2 |  tee /proc/sys/vm/overcommit_memory
			fi
		fi
	else
		echo 0 |  tee /proc/sys/vm/overcommit_memory
		if [[ $SYSTEM_SWAP_PARTITION_DETECTED == "true" ]]; then
			echo 4 |  tee /proc/sys/vm/zone_reclaim_mode
		elif [[ $RAM_CLASS == "verylow" || $RAM_CLASS == "low" || $RAM_CLASS == "mid" ]]; then
			echo 1 |  tee /proc/sys/vm/zone_reclaim_mode
		else
			echo 0 |  tee /proc/sys/vm/zone_reclaim_mode
		fi
	fi
	
}

ram_zram_configuration(){

	#DEFAULT VALUES
	ZRAM_ALGO="lz4hc"
	ZRAM_AMOUNT="2G"
	ZRAM_PRIORITY=500

    if [[ "$CPU_CLASS" == "verylow" || "$CPU_CLASS" == "low" ]]; then
		if [[ $RAM_CLASS == "verylow" || $RAM_CLASS == "low" ]]; then
            ZRAM_ALGO="lz4hc"
		else
			ZRAM_ALGO="lz4"
		fi
	elif [[ "$CPU_CLASS" == "mid" ]]; then
		if [[ $RAM_CLASS == "verylow" || $RAM_CLASS == "low" ]]; then
            ZRAM_ALGO="zstd"
		elif [[ $RAM_CLASS == "mid" ]]; then
			ZRAM_ALGO="lz4hc"
        else
            if [[ $STORAGE_ROOT_DEVICE_TYPE == "hdd" || $STORAGE_ROOT_DEVICE_TYPE == "usb" ]]; then
                ZRAM_ALGO="lz4hc"
            else
				ZRAM_ALGO="lz4"
            fi
        fi
	elif [[ "$CPU_CLASS" == "high" ]]; then
		if [[ $RAM_CLASS == "verylow" || $RAM_CLASS == "low" ]]; then
			ZRAM_ALGO="deflate"
		elif [[ $RAM_CLASS == "mid" ]]; then
			ZRAM_ALGO="zstd"
		elif [[ $RAM_CLASS == "high" ]]; then
			if [[ $STORAGE_ROOT_DEVICE_TYPE == "hdd" || $STORAGE_ROOT_DEVICE_TYPE == "usb" ]]; then
                ZRAM_ALGO="zstd"
            else
				ZRAM_ALGO="lz4hc"
            fi
        else
            if [[ $STORAGE_DEVICE_TYPE == "ssd" || $STORAGE_ROOT_DEVICE_TYPE == "hdd" || $STORAGE_ROOT_DEVICE_TYPE == "usb" ]]; then
                ZRAM_ALGO="lz4hc"
            else
				ZRAM_ALGO="lz4"
            fi
        fi
	fi

	TEMP_ZRAM_AMOUNT=$RAM_GB_PHYSICAL
	ZRAM_AMOUNT=$(($TEMP_ZRAM_AMOUNT + 1))
	
	modprobe zram
	echo ${ZRAM_ALGO} > /sys/block/zram0/comp_algorithm
	echo "${ZRAM_AMOUNT}G" > /sys/block/zram0/disksize
	mkswap /dev/zram0
	swapon -p ${ZRAM_PRIORITY} /dev/zram0


}

ram_swappiness
if [[ "$CPU_CLASS" == "high" ]]; then
	if [[ $OPTIMIZATION_PROFILE_USECASE == "server" ]]; then
		ram_deduplication
	fi
fi
ram_vm_optimizations
if [[ $RAM_CLASS == "verylow" || $RAM_CLASS == "low" || $SYSTEM_SWAP_PARTITION_DETECTED != "true" ]]; then
	#NOTE: It's not reccomended to have both ZSWAP and ZRAM active at once
	ram_zram_configuration
fi


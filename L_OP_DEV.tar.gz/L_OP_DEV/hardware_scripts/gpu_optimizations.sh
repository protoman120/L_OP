#!/bin/bash

##################################################################
#IMPORTANT: SCRIPT DIRS SETUP (OPTIMIZATIONS)
source ./utility_scripts/script_directories.sh
source $SAVED_OPTIMIZATION_GOALS
source $SAVED_CPU_DATA
source $SAVED_RAM_DATA
source $SAVED_ROOT_STORAGE_DATA
source $SAVED_SWAP_STORAGE_DATA
source $SAVED_OS_DATA
source $SAVED_DE_DATA
source $SAVED_BOOTLOADER_DATA
##################################################################

BASIC_GPU_COOLING_PROFILES=(
    "gpu_cooling_basic"
    "cpu+gpu_cooling_basic"
    "cpu+gpu_cooling+zram_basic"
    "gpu_cooling+zram_basic"
)

gpu_power_optimizations(){

	for GPU_FILE in "$SAVED_GPU_DATA_FOLDER"/card*/$SAVED_GPU_DATA_FILE_NAME; do

        source "$GPU_FILE"
	
		if [[ $OPTIMIZATION_PROFILE_USECASE == "desktop" ]] || [[ $OPTIMIZATION_PROFILE_USECASE == "server" ]] || [[ "$GPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
			echo auto | tee "$GPU_PCI_PATH/power/control"
			echo enabled | tee "$GPU_PCI_PATH/power/async"
		elif [[ $OPTIMIZATION_PROFILE_USECASE == "gaming" ]]; then
            echo on | tee "$GPU_PCI_PATH/power/control"
            echo enabled | tee "$GPU_PCI_PATH/power/async"
		else
			echo auto | tee "$GPU_PCI_PATH/power/control"
			echo disabled | tee "$GPU_PCI_PATH/power/async"
		fi
		
		if [[ "$GPU_VENDOR" == "amd" ]]; then
		    if [[ "$GPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
                if [[ $OPTIMIZATION_PROFILE == "AI_Self_Hosting" ]]; then
                    echo high | tee "$GPU_PCI_PATH/power_dpm_force_performance_level"
                else
                    if [[ "$GPU_TYPE" == "igpu" ]]; then
                        echo low | tee "$GPU_PCI_PATH/power_dpm_force_performance_level"
                    else
		                echo auto | tee "$GPU_PCI_PATH/power_dpm_force_performance_level"
                    fi
                fi
		    elif [[ "$GPU_OPTIMIZATION_GOAL" == "latency" ]]; then
		        echo high | tee "$GPU_PCI_PATH/power_dpm_force_performance_level"
		    else
		        echo auto | tee "$GPU_PCI_PATH/power_dpm_force_performance_level"
		    fi
		fi
		
		if [[ "$GPU_CLASS" == "intel" ]]; then
	        if [[ "$GPU_DRIVER" == "i915" ]]; then
		    	echo 1 | tee "/sys/module/i915/parameters/enable_fbc"
		    	echo 0 | tee "/sys/module/i915/parameters/enable_psr"
                if [[ "$GPU_OPTIMIZATION_GOAL" == "latency" ]]; then
                    echo 0 | tee "/sys/module/i915/parameters/d3cold_allowed"
                else
                    echo 1 | tee "/sys/module/i915/parameters/d3cold_allowed"
                fi
	        fi
		fi
	done
}

gpu_performance_optimizations() {

    for GPU_FILE in "$SAVED_GPU_DATA_FOLDER"/card*/$SAVED_GPU_DATA_FILE_NAME; do

        source "$GPU_FILE"

        if [[ "$GPU_VENDOR" == "nvidia" ]]; then
            if command -v nvidia-smi >/dev/null 2>&1; then
            	#pm = Persistence Mode
                nvidia-smi -pm 1
                
                #Value needs to be rounded without decimals to work properly
                GPU_POWER_CAP_W=${GPU_POWER_MAX_LIMIT%.*}

                #BASE VALUES
                GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=1
                GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=100
                GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=100
                #USED ONLY IF ENABLED ADDITIONAL/EXTREME GPU COOLING SETTINGS
                GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE_REDUCTION=0
                GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE_REDUCTION=0
                GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE_REDUCTION=0
                if [[ "$GPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
                    if [[ $OPTIMIZATION_PROFILE == "AI_Self_Hosting" ]]; then
                        if (( GPU_POWER_CAP_W >= 200 )); then
                            GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=1
                            GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=40
                            GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=95
                        elif (( GPU_POWER_CAP_W >= 100 )); then
                            GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=1
                            GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=45
                            GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=96
                        elif (( GPU_POWER_CAP_W >= 40 )); then
                            GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=1
                            GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=50
                            GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=98
                        fi
                    else
                        if (( GPU_POWER_CAP_W >= 200 )); then
                            GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=15
                            GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=80
                            GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=80
                        elif (( GPU_POWER_CAP_W >= 100 )); then
                            GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=1
                            GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=85
                            GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=85
                        elif (( GPU_POWER_CAP_W >= 40 )); then
                            GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=1
                            GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=90
                            GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=90
                        fi
                    fi
                elif [[ "$GPU_OPTIMIZATION_GOAL" == "latency" ]]; then
                    if (( GPU_POWER_CAP_W >= 200 )); then
                        GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=15
                        GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=75
                        GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=75
                    elif (( GPU_POWER_CAP_W >= 100 )); then
                        GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=20
                        GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=80
                        GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=80
                    elif (( GPU_POWER_CAP_W >= 40 )); then
                        GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=25
                        GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=85
                        GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=85
                    fi
                fi

                if [[ $EXTREME_GPU_COOLING == "enabled" || $ADDITIONAL_GPU_COOLING == "enabled" ]]; then
                    if [[ $EXTREME_GPU_COOLING == "enabled" ]]; then
                        GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE_REDUCTION=10
                        GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE_REDUCTION=20
                        GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE_REDUCTION=20
                    elif [[ $ADDITIONAL_GPU_COOLING == "enabled" ]]; then
                        GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE_REDUCTION=5
                        GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE_REDUCTION=10
                        GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE_REDUCTION=10
                    fi
                    GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE=$(( GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE - GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE_REDUCTION ))
                    GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE=$(( GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE - GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE_REDUCTION ))
                    GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE=$(( GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE - GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE_REDUCTION ))
                fi

                GPU_NVIDIA_NEW_MIN_GPU_CLOCK=$(( GPU_MAX_GRAPHICS_CLOCK * GPU_NVIDIA_NEW_MIN_GPU_CLOCK_PERCENTAGE / 100 ))
                GPU_NVIDIA_NEW_MAX_GPU_CLOCK=$(( GPU_MAX_GRAPHICS_CLOCK * GPU_NVIDIA_NEW_MAX_GPU_CLOCK_PERCENTAGE / 100 ))
                GPU_NVIDIA_NEW_GPU_MEM_CLOCK=$(( GPU_MAX_MEMORY_CLOCK * GPU_NVIDIA_NEW_GPU_MEM_CLOCK_PERCENTAGE / 100 ))

                nvidia-smi --lock-gpu-clocks=$GPU_NVIDIA_NEW_MIN_GPU_CLOCK,$GPU_NVIDIA_NEW_MAX_GPU_CLOCK
                nvidia-smi --lock-memory-clocks=$GPU_NVIDIA_NEW_GPU_MEM_CLOCK
            fi
        fi

        if [[ "$GPU_VENDOR" == "amd" ]]; then
            if [[ "$GPU_TYPE" == "dgpu" ]]; then
                if [[ "$GPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
                    echo ""
                elif [[ "$GPU_OPTIMIZATION_GOAL" == "latency" ]]; then
                    echo ""
                else
                    echo ""
                fi
            elif [[ "$GPU_TYPE" == "igpu" ]]; then
                echo ""
            fi
        fi

        if [[ "$GPU_CLASS" == "arc" ]]; then
        	if [[ "$GPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
                	echo ""
        	elif [[ "$GPU_OPTIMIZATION_GOAL" == "latency" ]]; then
                	echo ""
        	fi
        fi

        if [[ "$GPU_CLASS" == "intel" ]]; then
            if [[ "$GPU_OPTIMIZATION_GOAL" == "throughput" ]]; then
                #Lowers IGPU to minimum as it shoudn't be used on servers, the power saved can be used to improve CPU performance
                echo $GPU_FREQ_MIN | tee "$GPU_DRM_PATH/gt/gt0/rps_max_freq_mhz"
            elif [[ "$GPU_OPTIMIZATION_GOAL" == "latency" ]]; then
                #GPU_NEW_MIN_FREQ=$(( GPU_FREQ_MAX * 10 / 100 ))
                #echo $GPU_NEW_MIN_FREQ | tee "$GPU_DRM_PATH/gt/gt0/rps_min_freq_mhz"
                echo ""
                if [[ "$GPU_DRIVER" == "i915" ]]; then
                    echo ""
                fi
            fi
        fi
    done

}

gpu_auto_power_tuner() {

    for GPU_FILE in "$SAVED_GPU_DATA_FOLDER"/card*/$SAVED_GPU_DATA_FILE_NAME; do

        source "$GPU_FILE"

        if [[ "$GPU_CLASS" == "nvidia" ]]; then
            command -v nvidia-smi >/dev/null 2>&1 || continue
            nvidia-smi -pm 1
            
            #Value needs to be rounded without decimals to work properly
            GPU_POWER_CAP_W=${GPU_POWER_MAX_LIMIT%.*}
            GPU_MIN_POWER_W=${GPU_POWER_MIN_LIMIT%.*}
            GPU_POWER_W=${GPU_POWER_LIMIT%.*}
            
            if (( GPU_POWER_CAP_W >= 200 )); then
                GPU_NEW_CAP_W=$(( GPU_POWER_CAP_W * 85 / 100 ))
            elif (( GPU_POWER_CAP_W >= 100 )); then
                GPU_NEW_CAP_W=$(( GPU_POWER_CAP_W * 90 / 100 ))
            elif (( GPU_POWER_CAP_W >= 40 )); then
                GPU_NEW_CAP_W=$(( GPU_POWER_CAP_W * 95 / 100 ))
            else
                GPU_NEW_CAP_W="$GPU_POWER_W"
            fi

            if [[ $ADDITIONAL_GPU_COOLING == "enabled" ]]; then
                GPU_NEW_CAP_W_RED=$(( GPU_POWER_CAP_W * 10 / 100 ))
                GPU_NEW_CAP_W=$(( GPU_POWER_CAP_W - GPU_NEW_CAP_W_RED ))
            fi

            if (( GPU_NEW_CAP_W < GPU_MIN_POWER_W )); then
                GPU_NEW_CAP_W="$GPU_MIN_POWER_W"
            fi

            #pl = power limit
            nvidia-smi -pl "$GPU_NEW_CAP_W"
        fi

        if [[ "$GPU_CLASS" == "radeon" ]]; then

            if [[ -w "$GPU_PCI_PATH/power_dpm_force_performance_level" ]]; then
                echo balanced | tee "$GPU_PCI_PATH/power_dpm_force_performance_level"
            fi

            for POWER_CAP in "$GPU_PCI_PATH"/hwmon/hwmon*/power1_cap; do

                if (( GPU_POWER_CAP_W > 200 )); then
                    GPU_NEW_CAP=$(( GPU_POWER_CAP * 85 / 100 ))
                elif (( GPU_POWER_CAP_W > 100 )); then
                    GPU_NEW_CAP=$(( GPU_POWER_CAP * 90 / 100 ))
                else
                    GPU_NEW_CAP=$(( GPU_POWER_CAP * 95 / 100 ))
                fi
                echo $GPU_NEW_CAP | tee "POWER_CAP"
            done
        fi

        if [[ "$GPU_CLASS" == "apu" ]]; then
            echo ""
        fi

        if [[ "$GPU_CLASS" == "arc" ]]; then
            for POWER_CAP in "$GPU_PCI_PATH"/hwmon/hwmon*/power1_cap; do

                if (( GPU_POWER_CAP_W > 200 )); then
                    GPU_NEW_CAP=$(( GPU_POWER_CAP * 85 / 100 ))
                elif (( GPU_POWER_CAP_W > 100 )); then
                    GPU_NEW_CAP=$(( GPU_POWER_CAP * 90 / 100 ))
                else
                    GPU_NEW_CAP=$(( GPU_POWER_CAP * 95 / 100 ))
                fi
                echo "$GPU_NEW_CAP" | tee "$POWER_CAP"
            done
        fi

        if [[ "$GPU_CLASS" == "intel" ]]; then
            echo ""
        fi
    done
}

if [[ " ${BASIC_GPU_COOLING_PROFILES[*]} " == *" $OPTIMIZATION_PROFILE "* ]]; then
    gpu_performance_optimizations
    gpu_auto_power_tuner
elif [[ "$GPU_COOLING_OPTIMIZATION" == "enabled" ]]; then
    gpu_power_optimizations
    gpu_performance_optimizations
    gpu_auto_power_tuner
fi